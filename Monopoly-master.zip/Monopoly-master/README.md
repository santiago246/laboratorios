# Monopoly Project

- **Name**: Andrew Chen
- **Class**: CSCI103 (Introduction to Programming)

This program allows up to 4 players to play together on the same computer together and functions much like the original Monopoly game. The Game Board and cards are customized but the game pieces are pulled from the real versions of Monopoly. Everything was created from scratch using Photoshop and C++.
