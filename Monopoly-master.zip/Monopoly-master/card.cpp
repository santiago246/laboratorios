#include "card.h"

Card::Card(){
	name = "Monopoly Card";
}
