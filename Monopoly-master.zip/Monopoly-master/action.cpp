#include "action.h"

Action::Action(){
	name = "Action Name";
}

Action::Action(string inputName){
	name = inputName;
}

