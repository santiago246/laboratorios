#ifndef DICE_H
#define DICE_H

class Dice {

	private:
	    int sides;

	public:
	    //constructor
	    Dice(); 
	
	    //functions to get values
	    int rollDice();	    

};
#endif
